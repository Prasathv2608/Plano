﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebAPISample.DAL;
using WebAPISample.Models;
using WebAPISample.Business_Entity;
using System.Threading.Tasks;

namespace WebAPISample.BLL
{
    public class ImageService
    {
            public  static List<ImageModel> GetImages(DateTime startdate,DateTime endDate)
            {
                var ImageList = ImageRepository.GetImageList();

                if (!string.IsNullOrEmpty(startdate.ToString())&& !string.IsNullOrEmpty(endDate.ToString()))
                {
                    return (from m in ImageList
                            where (m.CreatedDate >= startdate && m.CreatedDate <= endDate)
                            select m).ToList();
                }
                return ImageList;
        }

       
    }
}
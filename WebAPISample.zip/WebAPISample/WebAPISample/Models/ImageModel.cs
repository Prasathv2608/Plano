﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPISample.Models
{
    public class ImageModel
    {
        public int ImageID { get; set; }
        public string ImageName { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ClassifiedImage { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using WebAPISample.Business_Entity;
using WebAPISample.BLL;
using WebAPISample.Models;

namespace WebAPISample.Controllers
{
    public class ImageController : ApiController
    {
        private DateTime? enddate;
        private DateTime? startdate;

        [HttpGet]
        public async Task<List<ImageModel>> GetImageAsync(DateTime startdate, DateTime enddate)
        {

            List<ImageModel> imagesResult = new List<ImageModel>();
            imagesResult = ImageService.GetImages(startdate, enddate);
            return imagesResult;
        }

    }

    public class ActionResult
    {
    }
}

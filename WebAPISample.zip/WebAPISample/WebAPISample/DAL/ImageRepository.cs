﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebAPISample.Models;

namespace WebAPISample.DAL
{
    public class ImageRepository
    {
        public static List<ImageModel> ImageList;

        /// <summary>
        /// get list of classified models
        /// </summary>
        /// <returns></returns>
        public static List<ImageModel> GetImageList()
        {
            if (ImageList == null
            || ImageList.Count == 0)
            {
                CreateImagesList();
            }
            return ImageList;
        }

        /// <summary>
        /// Init a list of classified items
        /// </summary>
        private static void CreateImagesList()
        {
            ImageList = new List<ImageModel>()
            {
                new ImageModel()
                {
                    ImageID = 1,
                    ImageName = "Car on Sale",
                    CreatedDate = DateTime.Now,
                    ClassifiedImage = "/carImageUrl.jpg"
                },
            };
        }
    }
}